#!/bin/bash
# Barman Backup Wrapper
#

SYS=$1
if [[ -n $SYS ]]
    then
        # Set Environment
        . ~barman/.bash_profile

        # do Barman Backup
        /usr/bin/barman backup $SYS

        # backup .history files
        SSH=$(barman show-server $SYS  | grep ssh_command | awk '{print $4}')
        DIR=/backup/barman/postgres/history_files
        rsync -az -e 'ssh -q' $SSH:$DATA/pg_xlog/*history $DIR/$SYS.020516/  2>/dev/null
        # New post task to allow us to validate backups, after th backup is complete
        BKUPLIST=$(barman list-files $SYS latest > $DIR/backup_file_list_$SYS.log)
    else
        echo "ERROR: No DB specified..."
        exit
fi

# save and exit
