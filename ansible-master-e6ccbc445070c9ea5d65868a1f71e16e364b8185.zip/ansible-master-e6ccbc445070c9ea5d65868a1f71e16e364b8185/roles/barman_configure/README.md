# README.md
# Ansible Role: barman 

An Ansible role that installs and configures Barman (Backup and Recovery Manager) -  a product by 2nd Quadrant. 

Supported versions of Linux:

- Red Hat Enterperise Linux - 7.x
- CentOS - 7.x

## Requirements

Requires that you have a PostgreSQL installed and configured with archive_mode=on

## Role Variables

Available variables are listed below, along with default values:

    barman_owner: barman 
    backup_mount: /backup
    barman_password: see ansible vault files 
    barman_home: /backup/barman 
    postgres_owner: postgres 
    postgres_home: /var/lib/pgsql

## Example Playbook

    - hosts: pgrd01
      roles:
        - { role: postgresql_install }
        - { role: postgresql_primary }
        - { role: barman }
