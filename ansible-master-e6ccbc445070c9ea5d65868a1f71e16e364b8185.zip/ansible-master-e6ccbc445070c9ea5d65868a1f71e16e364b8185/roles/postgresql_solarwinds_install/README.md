# README.md
# Ansible Role: postgresql_solarwinds_install 

An Ansible role that installs and configures the user roles required to integrate with Solarwinds

Supported versions of Linux:

- Red Hat Enterperise Linux - 7.x
- CentOS - 7.x

## Requirements

Requires that you have a PostgreSQL installation

## Role Variables

Available variables are listed below, along with default values:

    solarwinds_admin_user: solarwinds_admin 
    solarwinds_admin_password: see ansible vault 
    solarwinds_temp_dir: /tmp 
    pg_port: 5432 


## Example Playbook

    - hosts: pgrd01
      roles:
        - { role: postgresql_install }
        - { role: postgresql_primary }
        - { role: postgresql_solarwinds_install }
