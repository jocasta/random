#!/bin/python

###################################################################
#
# Title: pg_pull_abp
#
# Description: pulls data from the abp master environment
# based on configuration and triggered by RabbitMQ
# see confluence () for more information.
#
# Version: 1.3
# Date: 31/08/2016
# Last Updated: 20/09/2016
# Author: D Betts
#
###################################################################

import psycopg2
import sys
import cStringIO
import pika
import subprocess
import re
import datetime
import os

source = {}
target = {}
schemas = []

global target_new_med
global target_prev_med
global input_table_list
global config_file
global log_file
global alert_email
global temp_dir
global temp_file

config_file = "/usr/local/bin/scripts/pg_pull_abp.conf"
log_file = "/var/log/pg_pull_abp.log"
alert_email = "rosdba@ros.gov.uk"
temp_dir = "/backup/dumps"
temp_file = "temp_file.sql"


# configure rabbitmq channel
def configure_channel():
        connection = pika.BlockingConnection(pika.ConnectionParameters(
          host=rabbitmq_host))
        channel = connection.channel()
        channel.exchange_declare(exchange='abp_postgres',
          type='fanout')
        return channel

def write_to_log(message_in):
        # open file
        try:
                push = open(log_file,'ab')
                push.write(message_in)
                push.close()
        except:
                print "Cannot open log file (" + log_file + ") for writing\n"


# callback routine for rabbitmq channel
def callback(ch, method, properties, body):
        st = str(datetime.datetime.now())
        write_to_log(" [x] %r at %s\n" % (body, st))
        main_db()

# main db connect function
def db_connect(connect_string):
        try:
                conn = psycopg2.connect(connect_string)
                return conn
        except psycopg2.Error, e:
                connect_string = re.sub('password\S+','password=*****',connect_string)
                error_code = "ERROR: Cannot connect to database using credentials: " + connect_string + "\n"
                write_to_log(error_code)
                write_to_log("REASON: " + str(e.pgerror) + "\n")
                call_mail('ERROR',"Cannot connect to database on" + str(connect_string))
                exit()

# fetch all table meta
def table_list(curr,schema_in):
        list_return = []
        # if we have a single schema just pop the first entry into a string, otherwise use immutable lists.
        if len(schema_in) <= 1:
                single_schema = schema_in[0]
                table_string = "SELECT table_schema || '.' || table_name FROM information_schema.tables WHERE table_schema = '%s' AND table_name NOT LIKE '%%load_%%' and table_name NOT LIKE '%%bkp_%%' and table_name NOT LIKE '%%SFSYS%%'" % single_schema
        else:
                table_string = "SELECT table_schema || '.' || table_name FROM information_schema.tables WHERE table_schema in %s AND table_name NOT LIKE '%%load_%%' and table_name NOT LIKE '%%bkp_%%' and table_name NOT LIKE '%%SFSYS%%'" % (tuple(schema_in),)
        try:
                curr.execute(table_string)
                res = curr.fetchall()
                for row in res:
                        list_return.append(row[0])
        except psycopg2.Error, e:
                write_to_log("ERROR: Cannot fetch table list for copying\n")
                write_to_log("REASON: " + str(e.pgerror) + "\n")
                call_mail('ERROR', str(e.pgerror))
                exit()
        return list_return


def column_validation(curr,schema_in,table_in):
        col_array = []
        numcols_sql = "SELECT column_name FROM information_schema.columns WHERE table_name='%s' and table_schema='%s' AND table_name NOT LIKE '%%load_%%' and table_name NOT LIKE '%%bkp_%%' ORDER by column_name" % (table_in,schema_in)
        curr.execute(numcols_sql)
        res = curr.fetchall()
        for row in res:
                col_array.append(row[0])
        return col_array

def backup_tables(curr,schema_in,table_in):
        write_to_log("INFO: Backing up table " + schema_in + "." + table_in + "\n")
        dt_sql = "DROP TABLE IF EXISTS %s.bkp_%s" % (schema_in, table_in)
        ct_sql = "CREATE TABLE %s.bkp_%s AS SELECT * FROM %s.%s" % (schema_in, table_in, schema_in, table_in)
        curr.execute(dt_sql)
        curr.execute(ct_sql)

def load_tables(curr,schema_in,table_in):
        write_to_log("INFO: Creating load table " + schema_in + ".load_" + table_in + "\n")
        dt_sql = "DROP TABLE IF EXISTS %s.load_%s" % (schema_in, table_in)
        lt_sql = "CREATE TABLE %s.load_%s AS SELECT * FROM %s.%s WHERE 1=0" % (schema_in,table_in,schema_in,table_in)
        curr.execute(dt_sql)
        curr.execute(lt_sql)

# main data function
def main_db():

        # main db loop
        connect_source = "host=" + source['source_host'] + " port=" + source['source_port'] + " dbname=" + source['source_dbname'] + " user=" + source['source_user'] + " password=" + source['source_password']
        connect_target = "host=" + target['target_host'] + " port=" + target['target_port'] + " dbname=" + target['target_dbname'] + " user=" + target['target_user'] + " password=" + target['target_password']

        source_db = db_connect(connect_source)
        target_db = db_connect(connect_target)

        # only do stuff if we can connect to both target and source
        if source_db and target_db:
                        write_to_log("INFO: Connected to Source (" + source['source_dbname'] + " on " + source['source_host'] + ") and Target (" + target['target_dbname'] + " on " + target['target_host'] + ")\n")
                        source_curr = source_db.cursor()
                        target_curr = target_db.cursor()
                        # fetch table list for list of schemas from config file for each data source. If they don't match don't continue.
                        if input_table_list != 0:
                                        source_table_list = input_table_list
                                        target_table_list = input_table_list
                        else:
                                        source_table_list = table_list(source_curr,source_schemas)
                                        target_table_list = table_list(target_curr,target_schemas)
                        run_once = 0
                        for full_table in source_table_list:
                                        if full_table not in target_table_list:
                                                        error_code = "Cannot find table " + full_table + ". Exiting...\n"
                                                        write_to_log(error_code)
                                                        call_mail('ERROR',error_code)
                                                        exit()
                                        # validate columns
                                        (schema,table) = full_table.split('.')
                                        source_colArray = column_validation(source_curr,schema,table)
                                        target_colArray = column_validation(target_curr,schema,table)
                                        for entry in target_colArray:
                                                        if entry not in source_colArray:
                                                                        error_code = "Column discrepancy found. " + entry + " does not exist\n"
                                                                        write_to_log(error_code)
                                                                        call_mail('ERROR',"Column discrepancy found. See " + log_file + " for more information")
                                                                        exit()
                                        # backup target tables
                                        target_backup = backup_tables(target_curr,schema,table)
                                        # create load tables
                                        target_load = load_tables(target_curr,schema,table)
                                        # copy data to load tables
                        # also check columns match
                        for i in source_table_list:
                                try:
                                        (schema,table) = i.split('.')
                                        if os.path.isdir(temp_dir):
                                                try:
                                                        f = open(temp_dir + '/' + temp_file,'wb')
                                                        write_to_log("INFO: Copying Table: " + schema + ".load_" + table + "\n")
                                                        source_curr.copy_to(f,i)
                                                        f.close()
                                                except:
                                                        write_to_log("ERROR: Cannot open file: " + temp_file)
                                                        call_mail('ERROR', "Cannot open file: " + temp_file)
                                                        quit()
                                        else:
                                                write_to_log("ERROR: Temp Directory does not exist: " + temp_dir)
                                                call_mail('ERROR', "Temp Directory does not exist: " + temp_dir)
                                                quit()
                                        f = open(temp_dir + '/' + temp_file,'rb')
                                        target_curr.copy_from(f,schema + '.load_' + table)
                                        target_curr.execute("COMMIT;")
                                        row_count_validation(source_curr,target_curr,schema,table)
                                        f.close()
                                        # cleanup temp files
                                        os.remove(temp_dir + '/' + temp_file)
                                        if schema == 'abplus' and table == 'address_base_plus':
                                                target_prev_med = 0
                                                max_entry_validation(target_curr,schema,table,target_prev_med)
                                except psycopg2.Error, e:
                                        write_to_log("ERROR: Cannot copy data\n")
                                        write_to_log("REASON: " + str(e.pgerror) + "\n")
                                        call_mail('ERROR',str(e.pgerror))
                                        exit()
                        st = str(datetime.datetime.now())
                        write_to_log("INFO: Completed Copying Process at %s\n" % st)
        else:
                        error_code = "ERROR: Not connected, exiting...\n"
                        write_to_log(error_code)
                        call_mail('ERROR',error_code)
                        exit()

def call_mail(subject_in, mail_body_in,mail_to=None):
        if mail_to is None:
                mail_to = alert_email
        try:
                subprocess.check_output("echo -e \"" + mail_body_in + "\"| mailx -s " + subject_in + " " + mail_to, shell=True)
        except subprocess.CalledProcessError as o:
                print "error code", o.returncode, o.output

def row_count_validation(s_curr_in,t_curr_in,sch_in,t_in):
        s_curr_in.execute("SELECT count(*) FROM %s.%s" % (sch_in, t_in))
        t_curr_in.execute("SELECT count(*) FROM %s.%s" % (sch_in, t_in))
        t_count = t_curr_in.rowcount
        s_count = s_curr_in.rowcount
        if t_count != s_count:
                write_to_log("ERROR: Row count discrepancy on table " + t_in)
                call_mail("ERROR","Row count discrepancy on table " + t_in)

def max_entry_validation(curr_in,schema_in,table_in,prev_med_in):
        try:
                curr_in.execute("SELECT MAX(entry_date) FROM %s.load_%s" % (schema_in, table_in))
                res = curr_in.fetchall()
                for row in res:
                        target_new_med = row[0]
                curr_in.execute("SELECT MAX(entry_date) FROM %s.bkp_%s" % (schema_in, table_in))
                res = curr_in.fetchall()
                for row in res:
                        prev_med_in = row[0]
        except:
                target_new_med = 0
        if target_new_med == 0:
                write_to_log("WARN: No max entry date found since the copy of " + schema_in + "." + table_in)
                call_mail("WARNING","New warning when checking max entry_date, see log for more information")
        else:
                call_mail("SUCCESS","ABP Load Completed Successfully\n\nHere are the max entry dates:\nBefore: " + str(prev_med_in) + "\nAfter: " + str(target_new_med))


# read in config file
with open(config_file,'rb') as fo:
        for line in fo:
                if line.startswith('source_'):
                        res = line.split(':')
                        key = res[0].rstrip('\n')
                        value = res[1].rstrip('\n')
                        source[key] = value
                if line.startswith('target_'):
                        res = line.split(':')
                        key = res[0].rstrip('\n')
                        value = res[1].rstrip('\n')
                        target[key] = value
                if line.startswith('schemas'):
                        res = line.split(':')
                        data = res[1].rstrip('\n')
                        schemas = data.split(',')
                        target_schemas = schemas
                        source_schemas = schemas
                if line.startswith('rabbitmq'):
                        res = line.split(':')
                        global rabbitmq_host
                        rabbitmq_host = res[1].rstrip('\n')
                if line.startswith('tables'):
                        res = line.split(':')
                        data = res[1].rstrip('\n')
                        input_table_list = data.split(',')
                else:
                        input_table_list = 0

# main

push = open(log_file,'ab')

mq_channel = configure_channel()

result = mq_channel.queue_declare(exclusive=True)
queue_name = result.method.queue

mq_channel.queue_bind(exchange='abp_postgres',
queue=queue_name)

write_to_log(" [*] Waiting for Validation Messages from ABP. To exit press CTRL+C\n")
print(" [*] Waiting for Validation Messages from ABP. To exit press CTRL+C\n")

mq_channel.basic_consume(callback,
  queue=queue_name,
  no_ack=True)
mq_channel.start_consuming()



