Role Name
=========

RabbitMQ install - install epel release and rabbit mq, ensures service is started and no more.

Requirements
------------

Requires EPEL

Role Variables
--------------

- {{ rabbitmq_port }}  - set the port to start on
- {{ rabbitmq_data_dir }} - set the data directory 


Example Playbook
----------------

    - hosts: es-vrxi-pgrd04.control.ros.gov.uk 
      roles:
         - { role: rabbitmq_install }

License
-------

BSD

Author Information
------------------

Dale Betts - dale.betts@ros.gov.uk
