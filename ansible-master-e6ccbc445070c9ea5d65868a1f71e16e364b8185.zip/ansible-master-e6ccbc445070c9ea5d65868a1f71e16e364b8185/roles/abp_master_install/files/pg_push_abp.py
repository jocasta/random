#!/bin/python

import pika
import sys

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

# create exchange
channel.exchange_declare(exchange='abp_postgres',type='fanout')

message = ' '.join(sys.argv[1:]) or "Validation message received. Sending data."
channel.basic_publish(exchange='abp_postgres',routing_key='',body=message)

print("[x] Sent %r" % message)

connection.close()

