### Ansible Roles

- postgresql_install - Performs the PostgreSQL Installation
- postgresql_primary - Configures a PostgreSQL Primary
- postgresql_replica - Configures a PostgreSQL Replica/Read Slave 
- barman - Install and Configure the Backup and Recovery Manager
- postgresql_monitoring - Configures pgbadger, httpd and php services
- postgresql_solarwinds_install - Configures PostgreSQL for Solarwinds 

### Documentation:

For PostgreSQL as a service - call site.yml
For anything else create a .yml file and call your required roles. 
All roles are created in ansible-galaxy and will therefore have an individual README.md

### Usage

Use one of the pre-defined .yml files in the root directory to create a postgresql installation as you wish. This will primarily be the site.yml which will call the create_primary.yml which is what you will required most of the time.
Alternatively copy and paste one of the pre-defined .yml files and alter the roles to suit.
